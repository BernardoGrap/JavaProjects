package lista;
import java.util.Scanner;
public class Num01 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int num;
		
		System.out.println("Digite um n�mero: ");
		num = (int) ler.nextFloat();	
		
		num = num -1;
		System.out.println("O antecessor do n�mero digitado �: " +num);
		ler.close();
	}
}