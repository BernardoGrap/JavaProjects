package lista;
import java.util.Scanner;
public class Num11 {

			public static void main(String[] args) {
			double fat = 1;
			Scanner sc = new Scanner (System.in);
			System.out.println("Para parar o programa digite: 0 ou 0< ");
			System.out.println("Digite o n�mero: ");
			double num = sc.nextInt();
			
			while (num > 1){
				  fat = fat *num; num--;
			}
			
		System.out.println("O fatorial �: "+fat);	
		sc.close();
	}
}