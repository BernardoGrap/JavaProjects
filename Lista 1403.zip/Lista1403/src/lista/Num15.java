package lista;
import java.util.Scanner;
public class Num15 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int A, B, C;
		
		System.out.println("Digite um n�mero: ");
		A = (int) ler.nextFloat();
		
		System.out.println("Digite outro n�mero: ");
		B = (int) ler.nextFloat();
		
		System.out.println("Digite mais um n�mero: ");
		C = (int) ler.nextFloat();
		
		if (A < C +B && B < A+C && C < A+B) {
			System.out.println("� um tri�ngulo!");
		}else {
			System.out.println("N�o � um tri�ngulo!");
		}
			
	ler.close();
	}
}