package lista;
import java.util.Scanner;
public class Num06 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int num1, num2;

		System.out.println("Digite um n�mero: ");
		num1 = (int) ler.nextFloat();
		
		System.out.println("Digite um n�mero: ");
		num2 = (int) ler.nextFloat();
		
		if (num1 > num2) {
			System.out.println("O n�mero 1 � maior que o 2!");
		} else {
			System.out.println("O n�mero 2 � maior que o 1!");
		}
	ler.close();
	}
}