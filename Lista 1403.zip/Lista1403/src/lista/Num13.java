package lista;

public class Num13 {

	public static void main(String[] args) {
		int num = 0;
		
		for ( int cont=0 ; cont<1000 ; cont++ ) {
			num = cont +1;
			System.out.println(num);
		}
	}
}