package lista;
import java.util.Scanner;
public class Num08 {

		public static void main(String[] args) {
			Scanner ler = new Scanner(System.in);
			int num, num2, num3, maior = 0, menor = 0, meio = 0;
			
			System.out.println("Digite um n�mero");
			num = (int) ler.nextFloat();
			System.out.println("Digite outro n�mero");
			num2 = (int) ler.nextFloat();
			System.out.println("Digite o ultimo n�mero");
			num3 = (int) ler.nextFloat();
			
			if (num > num2 && num > num3 && num2 > num3) {
				System.out.println();
				maior = num;
				meio = num2;
				menor = num3;
				}

			if (num > num2 && num > num3 && num3 > num2) {
				System.out.println();
				maior = num;
				meio = num3;
				menor = num2;
				}
			
			if (num2 > num && num2 > num3 && num > num3) {
				System.out.println();
				maior = num2;
				meio = num;
				menor = num3;
				}
			
			if (num2 > num && num2 > num3 && num3 > num) {
				System.out.println();
				maior = num2;
				meio = num3;
				menor = num;
				}
			
			if (num3 > num2 && num3 > num && num > num2) {
				System.out.println();
				maior = num3;
				meio = num;
				menor = num2;
				}
			
			if (num3 > num2 && num3 > num && num2 > num) {
				System.out.println();
				maior = num3;
				meio = num2;
				menor = num;
				}
			
			System.out.println("A ordem crescente �: " +menor+meio +maior);
			System.out.println("A ordem decrescente �: " +maior +meio +menor);
			
		ler.close();
	}
}