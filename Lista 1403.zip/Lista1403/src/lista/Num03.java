package lista;
import java.util.Scanner;
public class Num03 {
	
	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		float sal, reaj;
		
		System.out.println("Digite o valor do seu sal�rio: ");
		sal =ler.nextFloat();
		
		System.out.println("Digite o valor do reajuste: ");
		reaj =ler.nextFloat();
		
		sal = sal - reaj;
		
		System.out.println("O valor do seu sal�rio apos o novo reajuste � de: " +sal);
	ler.close();
	}
}