package lista;

public class Num10 {
	
		public static void main(String[] args) {
	
			for (int i=1000; i < 2000; i++){
			    if (i%11==5) {
			        System.out.println(i);
		   }
		}	
	}
}