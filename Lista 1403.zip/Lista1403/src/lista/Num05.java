package lista;
import java.util.Scanner;
public class Num05 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int num;
		
		System.out.println("Digite um n�mero: ");
		num = (int) ler.nextFloat();	
		
		if (num >= 0) {
			System.out.println("O n�mero � positivo!");
		} else {
			System.out.println("O n�mero � negativo");
		}
		
	ler.close();
	}
}