package lista;

public class Num14 {

	public static void main(String[] args) {
		
		for ( int cont=1 ; cont<100 ; cont++ ) {
			cont = cont +2;
			System.out.println(cont);			
		}
	}
}