package lista;
public class Num19 {

	public static void main(String[] args) {
		for ( int cont=10 ; cont>0 ; cont-- ) {
			System.out.println(cont);
		}
	}
}