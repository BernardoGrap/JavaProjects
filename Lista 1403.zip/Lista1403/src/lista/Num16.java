package lista;
import java.util.Scanner;
public class Num16 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		String time1;
		String time2;
		int gol1, gol2;
		
		System.out.println("Digite o Nome do 1� time: ");
		time1 = ler.next();
		System.out.println("Digite o n�mero de gols do time 1: ");
		gol1 = ler.nextInt();
		
		System.out.println("Digite o Nome do 2� time: ");
		time2 =ler.next();
		System.out.println("Digite o n�mero de gols do time 2: ");
		gol2 =ler.nextInt();
		
		if (gol1 > gol2) {
			System.out.println("O vencedor � "+time1+" com " +gol1+ "gols");
		}
		
		if (gol2 > gol1) {
			System.out.println("O vencedor � "+time2+" com " +gol2+ " gols");
		}
		
		if (gol1 == gol2) {
			System.out.println("Empate!");
		}
		
	ler.close();
	}
}