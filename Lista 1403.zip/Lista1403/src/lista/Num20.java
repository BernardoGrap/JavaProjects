package lista;
public class Num20 {
	
		public static void main(String[] args) {
			
			
			for ( int cont=100 ; cont<111 ; cont++ ) {
				System.out.println(cont);
				
		}	
	}
}