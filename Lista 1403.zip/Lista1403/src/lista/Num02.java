package lista;
import java.util.Scanner;
public class Num02 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int A, B, C;
		
		System.out.println("Digite dois n�meros e eles trocaramd e lugar");
		System.out.println("Digite o valor de A: ");
		A = (int) ler.nextFloat();
		
		System.out.println("Digite o valor de B : ");
		B = (int) ler.nextFloat();
		
		C = A;
		A = B;

		
		System.out.println("A = " +A);
		System.out.println("B = " +C);
	ler.close();
	}
}