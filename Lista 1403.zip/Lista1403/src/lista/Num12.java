package lista;
public class Num12 {

	public static void main(String[] args) {

		for ( int cont=150 ; cont<301 ; cont++ ) {
			System.out.println(cont);
		}
		
	}
}