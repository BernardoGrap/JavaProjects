package lista;
import java.util.Scanner;
public class Num17 {

		public static void main(String[] args) {
			Scanner ler = new Scanner (System.in);
			System.out.println("Digite o tamanho da piramide: ");
			int num = ler.nextInt();
			
			for (int i=1; i <= num ; i++) {
					for (int j=1; j <= i ; j++) {
						System.out.print("*");
				}
					
				System.out.print("\n");
			}
		ler.close();
		}
	}