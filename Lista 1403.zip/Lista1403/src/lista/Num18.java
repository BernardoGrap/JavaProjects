package lista;
import java.util.Scanner;
import java.util.Random;
public class Num18 {

			public static void main(String[] args) {
		
			Random rnd = new Random(); 
			int x = rnd.nextInt(100); 
			int chute =0, tentativa = 0;
			
			Scanner ler = new Scanner(System.in);
			System.out.println("Digite 1 para come�ar: ");
			chute = (int) ler.nextFloat();
			
			while (chute != x){
				System.out.println("Chute um n�mero: ");
				chute = (int) ler.nextFloat();
				tentativa = tentativa+1;
				
				  if (chute > x){
					  System.out.println("O numero � menor!");
				  }
				  
				  if (chute < x){
					  System.out.println("O numero � maior!");
				  }
				
				  if (chute == x){
					  System.out.println("Parab�ns voc� acertou! O n�mero era " +x );
					  System.out.println("Voc� tentou acertar: " +tentativa);
				  }
				
			}
			ler.close();
		}
	}