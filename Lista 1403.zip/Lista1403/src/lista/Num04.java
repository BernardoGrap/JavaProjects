package lista;
import java.util.Scanner;
public class Num04 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int num;
		
		System.out.println("Digite um n�mero e descubra se � maior ou menor que 10!");
		num = (int) ler.nextFloat();
		
		if (num > 10) {
			System.out.println("O numero � maior que 10!");
		} else {
			System.out.println("O n�mero � menor que 10!");
		}
		
	ler.close();
	}
}