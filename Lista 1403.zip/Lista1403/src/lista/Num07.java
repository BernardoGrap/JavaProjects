package lista;
import java.util.Scanner;
public class Num07 {
	
		public static void main(String[] args) {
			Scanner ler = new Scanner(System.in);
			float numero1, numero2, numero3;
				
			System.out.println("Digite um n�mero");
			numero1 = (int) ler.nextFloat();
				
			System.out.println("Digite um n�mero");
			numero2 = (int) ler.nextFloat();
				
			System.out.println("Digite um n�mero");
			numero3 = (int) ler.nextFloat();
			
				if(numero1 > (numero2+numero3)) {
					System.out.println("O n�mero "+numero1+" � maior que a soma de "+numero2+" e "+numero3);
				}
				else {
					System.out.println("O n�mero n�o "+numero1+" � maior que a soma de "+numero2+" e "+numero3);
				}
			
	ler.close();
	}
}