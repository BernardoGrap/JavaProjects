package lista;
import java.util.Scanner;
public class Num09 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
			int nota;
				
			System.out.println("Digite um n�mero para saber sua nota entre A-F, sendo: ");
			System.out.println("A = 90 at� 100");
			System.out.println("B = 80 at� 89");
			System.out.println("C = 70 at� 79");
			System.out.println("D = 60 at� 69");
			System.out.println("E = 50 at� 59");
			System.out.println("F = 49 ou menos");
			System.out.println("Digite a nota: ");
				
			Scanner nota1 = new Scanner (System.in);
			nota = ler.nextInt();
				
			if(nota >= 90 && nota <= 100) {
				System.out.println("Voc� � nota A!");
			}
				
			if(nota >= 80 && nota <= 89) {
				System.out.println("Voc� � nota B!");
			}
				
			if(nota >= 70 && nota <= 79) {
				System.out.println("Voc� � nota C!");
			}
				
			if(nota >= 60 && nota <= 69) {
				System.out.println("Voc� � nota D!");
			}
				
			if(nota >= 50 && nota <= 59) {
				System.out.println("Voc� � nota E!");
			}
				
			if(nota >= 0 && nota <=49) {
				System.out.println("Voc� � nota F!");
			}
				
			if(nota <= 0) {
				System.out.println("Digite um n�mero v�lido!");
			}
				
			if(nota >100) {
				System.out.println("Digite um n�mero v�lido!");
			}
		ler.close();
		nota1.close();
	}
}